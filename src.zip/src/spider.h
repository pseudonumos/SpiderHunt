#pragma once

#include <cmath>
#include <vector>

#include "algebra3.h"
#include "global.h"

#include "LoadImage.h"
#include "BSpline.h"
#include "algebra3.h"
#include "ccMap.h"

class bullet {
public:
	vec3 start; vec3 dir; vec3 current;
	bullet() {	}
	void render(){
		glPushMatrix();
		
		glBegin(GL_LINES);
		glVertex3f(current[0], current[1], current[2]);
		current[0] = current[0] + dir[0]; current[1] = current[1] + dir[1]; current[2] = current[2] + dir[2];
		glVertex3f(current[0], current[1], current[2]);
		glEnd();
		glPopMatrix();
	}
};

class Spider {
public:
	bool render(bool showHealth = false, bullet * b = NULL);
	Spider(face * f, double t_init = 0);
	~Spider(void);

private:
	int health;
	face * myFace;
	vec3 o;
	double t;
	bool alive;
};