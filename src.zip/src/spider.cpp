#include "spider.h"

#include "global.h"

#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void renderBitmapString(float x, float y, void *font, char *string) 
{  
  char *c;
  glRasterPos2f(x,y);
  for (c=string; *c != '\0'; c++) 
  {
    glutBitmapCharacter(font, *c);
  }
}


void glThickLine(vec3 start, vec3 end, double thick){
	glBegin(GL_QUAD_STRIP);
		glVertex3f(start[0], start[1], start[2]);
		glVertex3f(end[0], end[1], end[2]);	
		glVertex3f(start[0] - thick, start[1], start[2]);
		glVertex3f(end[0] - thick, end[1], end[2]);
		glVertex3f(start[0] - thick, start[1] - thick, start[2]);
		glVertex3f(end[0] - thick, end[1] - thick, end[2]);
		glVertex3f(start[0], start[1] - thick, start[2]);
		glVertex3f(end[0], end[1] - thick, end[2]);

	glEnd();

}
Spider::Spider(face * f, double t_init){
	myFace = f;
	o = vec3(1, 0, 0);
	t = t_init;
	health = 100; alive = true;
}

Spider::~Spider(void){
}

bool Spider::render(bool showHealth, bullet * b) {
	if (!alive) return false;
	bool ret = false;
	double t_local = t;
	//Check for hit
	if (b!= NULL){
	vec3 d = vec3(myFace->centroid()[0] + cos(t_local/6), myFace->centroid()[1], myFace->centroid()[2] + 0.5 - sin(t) / 6)
		- b->current;
	if (d.length2() < 0.3){
		cout << "HIT";
		ret = true;
		health-= 25;
		if (health <= 0) alive= false;
	}
	}
	//render spider body
	glTranslatef(myFace->centroid()[0] + cos(t_local/6), myFace->centroid()[1], myFace->centroid()[2] + 0.5 - sin(t) / 6);
	glTexCoord2f(0, 0);
	glPushMatrix();
	glScalef(o[0]+1, o[1]+1, o[2]+1);
	glRotatef(5 * sin(t), 0, 0, 1);
	glutSolidSphere(.3, 6, 6);
	glPopMatrix();
	char s[5];
	itoa(health, s, 10);
	strcat(s, "%");
	glPushMatrix();
	glRotatef(90, 0, 0, 1);
	if (showHealth) renderBitmapString(0, 0, GLUT_BITMAP_TIMES_ROMAN_24, s);
	glPopMatrix();
	//render spider eyes
	glPushMatrix();
		glTranslatef(-0.5, 0.15, 0.06);
		glutSolidSphere(0.1, 4, 4);
		glTranslatef(0, - 0.3, 0);
		glutSolidSphere(0.1, 4, 4);
	glPopMatrix();
	//render spider legs
	int i=0;
	while(i < 4){
		glTranslatef( - 0.1 + 0.1 * i, 0, 0);
		glThickLine(vec3(0,0,0), vec3(0, 0.6, sin(t) / 4), 0.05);
		glThickLine(vec3(0, 0.6, sin(t) / 4), vec3(0, 0.75, sin(t) / 4 - 0.5), 0.05);
		glThickLine(vec3(0,0,0), vec3(0, - 0.6, sin(t) / 4), 0.05);
		glThickLine(vec3(0, - 0.6, sin(t) / 4), vec3(0, -0.75, sin(t) / 4 - 0.5), 0.05);
		i++;
		t_local+= 0.1;
	}
	
	//cout << myFace->().normalize();
	t+= 0.24;
	return ret;
	
}
