#include "cloth.h"

#include "global.h"

#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Shaders.h"

namespace { // some anonymous helpers for file reading
    // get a quoted string, unless there's no quote at the start
    // in that case we just get whatever is there.
    string getQuoted(istream &str) {
        string ret;
        char temp;
        str >> temp;
        if (temp != '"') {
            str.putback(temp);
            str >> ret;
        } else {
            getline(str, ret, '"');
        }
        return ret;
    }

    void getValue(istream &str, int &val) {
        int v;
        if (str >> v)
            val = v;
    }
}

Cloth::Cloth(string filename,  string vertProg, string fragProg) {
	// define external forces
	gravity = 1/mass * vec3(0, -9.8, 0);
	wind = vec3(.2, .2, -1);


	int negativeBounds = -5;
	int positiveBounds = 5;

	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			nodes[i][j] = new node(vec3(negativeBounds + i*((positiveBounds - negativeBounds)/height), negativeBounds + j*((positiveBounds - negativeBounds)/width), 0));
		}
	}

	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			//if (i == 0 && j == width -1) continue;
			//if (i == height - 1 && j == width - 1) continue;
			// Structural Springs
			// set adjacent nodes
			if (i != 0) {
				nodes[i][j]->adjNodes.push_back(nodes[i-1][j]);		
			}
			if (j != 0) {
				nodes[i][j]->adjNodes.push_back(nodes[i][j-1]);
			}
			if (i != height - 1) {
				nodes[i][j]->adjNodes.push_back(nodes[i+1][j]);
			}
			if (j != width - 1) {
				nodes[i][j]->adjNodes.push_back(nodes[i][j+1]);
			}

			// Shear Springs
			// set diagonal nodes
			if (i != 0 && j != 0) {
				nodes[i][j]->adjNodes.push_back(nodes[i-1][j-1]);		
			}
			if (i != 0 && j != width - 1) {
				nodes[i][j]->adjNodes.push_back(nodes[i-1][j+1]);
			}
			if (i != height - 1 && j != 0) {
				nodes[i][j]->adjNodes.push_back(nodes[i+1][j-1]);
			}
			if (i != height - 1 && j != width - 1) {
				nodes[i][j]->adjNodes.push_back(nodes[i+1][j+1]);
			}
			
			// Flexion Springs
			// set diagonal and adjacent nodes of length 2
			if (i < height - 2 && j < width - 2) {
				nodes[i][j]->flexNodes.push_back(nodes[i+2][j+2]);
			}
			if (i < height - 2 && j > 1) {
				nodes[i][j]->flexNodes.push_back(nodes[i+2][j-2]);
			}
			if (j < width - 2 && i > 1) {
				nodes[i][j]->flexNodes.push_back(nodes[i-2][j+2]);
			}
			if (i < height - 2) {
				nodes[i][j]->flexNodes.push_back(nodes[i+2][j]);
			}
			if (j < width - 2) {
				nodes[i][j]->flexNodes.push_back(nodes[i][j+2]);
			}
			if (i > 1 && j > 1) {
				nodes[i][j]->flexNodes.push_back(nodes[i-2][j-2]);
			}
			if (i > 1) {
				nodes[i][j]->flexNodes.push_back(nodes[i-2][j]);
			}
			if (j > 1) {
				nodes[i][j]->flexNodes.push_back(nodes[i][j-2]);
			}
			
		}
	}

		//cubeVerts.push_back(vec3(
    // Load the track file
    ifstream f(filename.c_str());
    if (!f) {
        UCBPrint("Sweep", "Couldn't load file " << filename);
        return;
    }
    string line;
    while (getline(f,line)) {
        stringstream linestream(line);
        string op;
        linestream >> op;
        if (op[0] == '#') // comments are marked by # at the start of a line
            continue;
        if (op == "p") { // p marks profile points (2d cross section vertices)
        } else if (op == "v") { // v marks bspline control points with optional azimuth info
        } else if (op == "twist") {
        } else if (op == "azimuth") {
        } else if (op == "texture") {
            string textureFile = getQuoted(linestream);
            loadTexture(textureFile, texture);
        } else if (op == "bump") {
            string bumpFile = getQuoted(linestream);
            loadHeightAndNormalMaps(bumpFile, heightMap, normalMap, .2);
        }
    }

    // compile link and validate shader programs
    shadersFailed = false;
    program = glCreateProgramObjectARB();
    if (!setShader(program, vertProg.c_str(), GL_VERTEX_SHADER_ARB))
        shadersFailed = true;
    if (!setShader(program, fragProg.c_str(), GL_FRAGMENT_SHADER_ARB))
        shadersFailed = true;
    if (!linkAndValidateShader(program))
        shadersFailed = true;

    if (shadersFailed) {
        cout << "Shaders failed to initialize correctly" << endl;
    }

    // start with all the nice settings on
    shadersOn = false;
    bumpMapEnabled = false;
    textureMapEnabled = true;

    // set up variables for the shaders to use
    glUseProgramObjectARB(program);
    glUniform1iARB(glGetUniformLocationARB(program, "textureMap"), 0);
    glUniform1iARB(glGetUniformLocationARB(program, "heightMap"), 1);
    glUniform1iARB(glGetUniformLocationARB(program, "normalMap"), 2);
    bumpMapEnabledUniform = glGetUniformLocationARB(program, "bumpMapEnabled");
    textureMapEnabledUniform = glGetUniformLocationARB(program, "textureMapEnabled");
    tangentAttrib = glGetAttribLocationARB(program, "tangent");
    bitangentAttrib = glGetAttribLocationARB(program, "bitangent");

}


Cloth::~Cloth() {


}

void Cloth::setWindForce() {
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			vec3 force = vec3(0, 0, 0);
			vec3 p = nodes[i][j]->pos;
			if (i != height - 1 && j != width - 1) {
				vec3 v1 = nodes[i+1][j]->pos;
				vec3 v2 = nodes[i][j+1]->pos;
				vec3 n = (v1 - p) ^ (v2 - p);
				vec3 norm = n;
				force = norm.normalize() * (n * wind);
				nodes[i][j]->force += force;
				nodes[i+1][j]->force += force;
				nodes[i][j+1]->force += force;
				nodes[i][j]->normal = norm;
			}
			if (i != 0 && j != 0) {
				vec3 v1 = nodes[i][j-1]->pos;
				vec3 v2 = nodes[i-1][j]->pos;
				vec3 n = (v1 - p) ^ (v2 - p);
				vec3 norm = n;
				force = norm.normalize() * (n * wind);
				nodes[i][j]->force += force;
				nodes[i][j-1]->force += force;
				nodes[i-1][j]->force += force;
				nodes[i][j]->normal = norm;
			}
		}
	}

}

void Cloth::renderCloth() {
    if (shadersOn) {
        glUseProgramObjectARB(program);
        glUniform1iARB(bumpMapEnabledUniform, bumpMapEnabled);
        glUniform1iARB(textureMapEnabledUniform, textureMapEnabled);
    } else {
        glUseProgramObjectARB(0);
    }

    // load textures
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, heightMap);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, normalMap);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);

	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			vec3 springForce = nodes[i][j]->getSpringForce();
			vec3 gravityForce = gravity;
			if (i == height - 1 && j == 0) {
				
			} else if (i == height - 1 && j == width - 1) {
			
			} else {
				nodes[i][j]->applyForce(springForce + gravityForce + nodes[i][j]->force);
			}
		}
	}
	glBegin(GL_QUAD_STRIP);
	for (int i = 0; i < height - 1; i++) {
		for (int j = 0; j < width; j++) {
			vec3 p = nodes[i][j]->getPos();
			vec3 pp = nodes[i+1][j]->getPos();
			glNormal3d(nodes[i][j]->normal[0], nodes[i][j]->normal[1], nodes[i][j]->normal[2]);
			glTexCoord2f( ((double) i )/ height, ((double) j)/ width);
			glVertex3f(p[0], p[1], p[2]);

			glNormal3d(nodes[i+1][j]->normal[0], nodes[i+1][j]->normal[1], nodes[i+1][j]->normal[2]);
			glTexCoord2f( ((double) i+1 ) / height, ((double) j ) / width);
			glVertex3f(pp[0], pp[1], pp[2]);
		}
	}
	glEnd();
}